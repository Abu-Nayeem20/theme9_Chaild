<?php

function theme9_child_assets(){
	wp_enqueue_style("theme9-parent-stylesheet", get_parent_theme_file_uri('/style.css'),'',' 1.1.0');
}
add_action("wp_enqueue_scripts","theme9_child_assets");


